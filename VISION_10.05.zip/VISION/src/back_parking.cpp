#include "StereoVision.h"
#include "StereoVision.cpp"

#define LEFT_CAM 7
#define RIGHT_CAM 10

using namespace cv;
using namespace std;

ros::Publisher encoder_pub;
ros::Subscriber LiDAR_Stop_sub;
ros::Subscriber mission_sub;

float baseline = 23; //카메라 사이 거리
float focal_pixels = 800; // size(1280, 720) 일때 focal_pixels
float alpha = 10.5;	//alpha = 카메라 머리 숙인 각도
float beta = 43.8496; 	//beta = erp 헤딩으로부터 카메라 각도
float gps_for_camera_x = 30; //cm
float gps_for_camera_z = -42; //cm

int encoder_count = 0;
bool LiDAR_Stop = false;
bool encoder = false;
int mission_flag = 0;

void Lidar_callback(const std_msgs::Bool::ConstPtr& msgs)
{
	LiDAR_Stop = msgs->data;
}

void mission_cb(const std_msgs::Int16::ConstPtr& msgs)
{
	mission_flag = msgs->data;
}

int main(int argc, char **argv) 
{   
	ros::init(argc, argv, "parking_publisher");
	ros::NodeHandle nh;
	image_transport::ImageTransport it(nh);
	encoder_pub = nh.advertise<std_msgs::Bool>("Vision/back_parking", 10);
    LiDAR_Stop_sub = nh.subscribe("/LiDAR/Parallel_Stop", 10, Lidar_callback);
    mission_sub = nh.subscribe("/Planning/mission", 10, mission_cb);

	string left_cam_index = "/dev/video" + to_string(LEFT_CAM);
	string right_cam_index = "/dev/video" + to_string(RIGHT_CAM);
	
	// VideoCapture capLeft(left_cam_index);
    // VideoCapture capRight(right_cam_index);

	VideoCapture capLeft("/home/korus/catkin_ws/src/record_video/stereo_video/left_0917.mp4");
    VideoCapture capRight("/home/korus/catkin_ws/src/record_video/stereo_video/right222.mp4");

	if (!capLeft.isOpened()) {
        cout << "Cannot Open Left Camera" << endl;
    }
    if (!capRight.isOpened()) {
        cout << "Cannot Open Right Camera" << endl;
    }

    capLeft.set(cv::CAP_PROP_FRAME_WIDTH, 1280);
    capLeft.set(cv::CAP_PROP_FRAME_HEIGHT, 720);
    capRight.set(cv::CAP_PROP_FRAME_WIDTH, 1280);
    capRight.set(cv::CAP_PROP_FRAME_HEIGHT, 720);

    StereoVision stereovision(baseline, focal_pixels);

	Mat leftFrame, rightFrame;
	Mat leftMask, rightMask;

    while (ros::ok()) 
    {
		capLeft.read(leftFrame);
		capRight.read(rightFrame);
		resize(leftFrame, leftFrame, Size(1280, 720));
		resize(rightFrame, rightFrame, Size(1280, 720));

		if((mission_flag == 13)||(mission_flag == 12))
		{
			std_msgs::Bool encoder_mode_msg;
			
			rectangle(leftFrame, Rect(0, 0, 1280, 200), Scalar(0, 0, 0), -1); //상단 for koreatech
			rectangle(rightFrame, Rect(0, 0, 1280, 200), Scalar(0, 0, 0), -1); //상단 for koreatech

			// imshow("Left Frame", leftFrame);
			// imshow("Right Frame", rightFrame);

			leftMask = stereovision.add_HSV_filter(leftFrame, 0);
			rightMask = stereovision.add_HSV_filter(rightFrame, 1);

			dilate(leftMask, leftMask, (3, 3));
			dilate(rightMask, rightMask, (3, 3));
			
			erode(leftMask, leftMask, (3, 3));
			erode(rightMask, rightMask, (3, 3));

			imshow("Left mask", leftMask);
			imshow("Right mask", rightMask);

			if(LiDAR_Stop == true)
			{
				if(encoder == false)
				{
					vector <Vec4i> leftlines;
					HoughLinesP(leftMask, leftlines, 1, CV_PI / 180, 50, 100, 20);

					vector <Vec4i> rightlines;
					HoughLinesP(rightMask, rightlines, 1, CV_PI / 180, 50, 100, 20);

					Mat leftLine = Mat(leftFrame.size(), CV_8UC1, Scalar(0, 0, 0));
					Mat leftLine_minus = Mat(leftFrame.size(), CV_8UC1, Scalar(0, 0, 0));

					Mat rightLine = Mat(rightFrame.size(), CV_8UC1, Scalar(0, 0, 0));
					Mat rightLine_minus = Mat(rightFrame.size(), CV_8UC1, Scalar(0, 0, 0));

					for (Vec4i l : leftlines)
					{
						float dx = l[2] - l[0], dy = l[3] - l[1];
						float k = dy / dx;
						float radian = atan(k);
						float theta = (radian * 180) / CV_PI;
						
						if ((theta > -90 && theta < 0))
						{
							line(leftLine, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(255, 255, 255), 30, LINE_AA);
						}
						else  
						{
							line(leftLine_minus, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(255, 255, 255), 30, LINE_AA);
						}
					}

					for (Vec4i l : rightlines)
					{
						float dx = l[2] - l[0], dy = l[3] - l[1];
						float k = dy / dx;
						float radian = atan(k);
						float theta = (radian * 180) / CV_PI;
						
						if ((theta > -90 && theta < 0))
						{
							line(rightLine, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(255, 255, 255), 30, LINE_AA);
						}
						else  
						{
							line(rightLine_minus, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(255, 255, 255), 30, LINE_AA);
						}
					}

					// imshow("leftLine",leftLine);
					// imshow("leftLine_minus",leftLine_minus);

					// imshow("rightline",rightLine);
					// imshow("rightline_minus",rightLine_minus);

					subtract(leftLine, leftLine_minus, leftLine);
					subtract(rightLine, rightLine_minus, rightLine);

					// imshow("leftLine - leftLine_minus", leftLine);
					// imshow("rightLine - rightLine_minus", rightLine);

					Mat leftFinal;
					Mat rightFinal;

					bitwise_and(leftMask,leftLine,leftFinal);
					bitwise_and(rightMask,rightLine,rightFinal);

					// imshow(" leftFinal " , leftFinal);
					// imshow(" rightFinal " , rightFinal);

					Point2f leftPoint = stereovision.back_park(leftFinal,0);
					Point2f rightPoint = stereovision.back_park(rightFinal,1);

					// cout << " left point : " << leftPoint << endl;
					// cout << " right point : " << rightPoint << endl;
			
					float Z_distance = 0;
					Point2f distance_XZ = {0,0};

					if (leftPoint.x && rightPoint.x)
					{
						distance_XZ = stereovision.find_XZ(leftPoint, rightPoint, leftFrame, rightFrame, alpha, beta);
						// cout << "distance_XZ : " << distance_XZ << endl;
						Z_distance = (distance_XZ.x + gps_for_camera_z)/100.00;
					}
					cout << " X 거리 : " << Z_distance << endl;

					if((Z_distance < 1.50) && (Z_distance > 0))
					{
						encoder_count++;
					}
					else
					{
						encoder = 0;
						encoder_count = 0;
					}

					if(encoder_count >2)
					{
						encoder = 1;
					}
				}
				encoder_mode_msg.data = encoder;
				encoder_pub.publish(encoder_mode_msg);
				// ROS_INFO("%d", encoder_mode_msg.data);
				cout << "encoder_mode_msg.data: " << encoder << endl;
			}
		}
		else
		{
			cout << " waitting for mission flag " << endl;
		}
		
		if (waitKey(10) == 27)
        {
            break;
            printf("end");
        }
		ros::spinOnce();
	}
    return 0;
}